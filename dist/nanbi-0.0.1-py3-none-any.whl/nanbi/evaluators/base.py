class Evaluator:
    pass
